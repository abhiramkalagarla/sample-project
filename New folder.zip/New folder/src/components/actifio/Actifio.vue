<template>
  <div class="mt-2">
  <b-form @submit="onSubmitform">
  <b-row>
  <b-col md="8">
  
    <b-form-group id="Group1"
                  label="CSI Application ID"
                  class="required"
                  description="To get App Manager and Billing ID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="appID">
                  <b-input-group>
    <b-form-input id="appID"
                    type="text"
                    v-model="actifio.CSIID"
                    aria-describedby="appID"
                    placeholder="Enter CSI App ID" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getAppInfo()">Lookup</b-btn>
                    </b-input-group-append>
                    </b-input-group>
      <span class="invalid-feedback d-block" v-if="isValidCSIID">The Entered CSIID is invalid. Please try again...</span>
    </b-form-group>

    <b-form-group id="OfflinePools"
    class="required"
                  label="Billing ID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="billingID">
    <b-form-select id="billingID"
                 :options="billingId"
                  v-model="actifio.billingID"
                  aria-describedby="billingID"
                  placeholder="Select Billing ID" />
    </b-form-group>

    <b-form-group id="OfflinePools"
    class="required"
                  label="Enter DBA Group dl"
                  description="To validate dl in LDAP"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="groupdl">
      <b-form-select id="datacenter"
                    :options="groupDl"
                    v-model="actifio.groupDl"
                    aria-describedby="groupdl"
                    placeholder="Enter DBA Group dl"/>
    </b-form-group>

    <b-form-group id="backuppurpose"
    class="required"
                  label="Select the Backup Purpose"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="backuppurpose">
      <b-form-select id="backuppurpose"
                    :options="backupPurpose"
                    v-model="actifio.backupPurpose"
                    aria-describedby="backuppurpose"
                    placeholder="Select the Backup Purpose"/>
    </b-form-group>

    <b-form-group id="OfflinePools"
    class="required"
                  label="Select the Database Type"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="database">
      <b-form-select id="database"
                    :options="database"
                    v-model="actifio.database"
                    aria-describedby="database"
                    placeholder="Select the Database Type"/>
    </b-form-group>
  </b-col>
  </b-row>
  
<mssqlTable v-if="actifio.database==='MSSQL'" @update="onChildUpdate"></mssqlTable>
<oracle v-if="actifio.database==='Oracle'"></oracle>
    <b-row>
    <b-col  md="8" offset-md="4" class="mt-1">
      <button  class="btn btn-primary" :disabled="$v.actifio.$invalid">Submit the DPS Order</button> 
    </b-col>
    </b-row>
      </b-form>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import mssqlTable from './mssqlTable.vue'
import oracle from './oracle.vue'
export default {
  name: 'Dashboard',
  components: { mssqlTable, oracle },
  data () {
    return {
         billingId: [],
         groupDl: [],
         isValidCSIID: false, 
         showMsSqlTable: false,
         showOracleTable: false,
         backupPurpose: ['Choose...', 'Appendix J', 'Non - ORAAS', 'VM Backup'],
         database: [{ value: null, text: 'Please select Database' }, 'MSSQL', 'Oracle'],
         actifio: {},
         actinfolookup: {},
         template: 'default'
    }
  },
  mixins: [validationMixin],
  validations: {
    actifio: {
      CSIID: {
        required
      },
      billingID: {
        required
      },
      groupDl: {
        required
      },
      backupPurpose: {
        required
      },
      database: {
        required
      }
    }
  },
  created () {
    // this.getAppInfo();
    this.getusergroups()
  },
  watch: {
'actifio.CSIID': function (val, oldVal) {
  this.billingId = []
}
  },
  methods: {
    onChildUpdate (nvalue) {
console.log(nvalue)
    },
    onSubmitform (e) {
      e.preventDefault()
      this.postSubmitOrder()
      },
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getAppInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .get('https://mystorage.nam.nsroot.net:8080/api/apps?CSIID=' + this.actifio.CSIID, {}, apiheaders)
        .then((response) => {
         this.billingId = response.body.billingIDs
         this.isValidCSIID = false;
        })
        .catch((response) => {
          this.isValidCSIID = true;
          // this.$toasted.show('The Entered CSIID is invalid. Please try again...', {type: 'error', duration: 5000})
          console.log(response)
        })
    },
    getemailDL (data) {
      var c = []
      for (var i = 0; i < data.length; i++) {
        if (data[i].split(',')[1].split('=')[1] === 'Dist_Grps' || data[i].split(',')[1].split('=')[1] === 'Dist_Groups') {
        c.push({value: data[i], text: data[i].split(',')[0].split('=')[1]})
            }
      }
      this.groupDl = c;
    },
    getusergroups () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .get('https://mystorage.nam.nsroot.net:8080/api/user/groups', apiheaders)
        .then((response) => {
          this.getemailDL(response.body)
        })
        .catch((response) => {
          console.log(response)
        })
    },
    postSubmitOrder () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .post('https://mystorage.nam.nsroot.net:8080/dps/create' + this.actifio.CSIID, {}, apiheaders)
        .then((request) => {
         
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>
