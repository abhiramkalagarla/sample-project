<template>
<b-tabs nav-class="nav-wizard" v-model="tabIndex">
  <b-tab title="Basic Details" class="mt-3" active :title-item-class="linkActive(0)">
  <b-row>
  <b-col md="8" sm="12" xs="12">
     <b-form-group id="exampleInput1"
                    label="Resource Name:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                   
                    label-for="exampleInput1">
        <b-form-input id="resourceName"
                      label="Resource Name"
                      label-for="exampleInput2"
                      v-model="basic.resourceName"
                      @input="$v.basic.resourceName.$touch()"
                      :state="!$v.basic.resourceName.$invalid"
                      placeholder="Enter Resource Name">
        </b-form-input>
      </b-form-group>

      <b-form-group id="formcsiID"
                    label="CSIID:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="formcsiID">
          <b-form-input id="csiID"
                      label="csiID"
                      label-for="exampleInput2"
                      v-model="basic.csiID"
                      @input="$v.basic.csiID.$touch()"
                      :state="!$v.basic.csiID.$invalid"
                      placeholder="Enter CSIID">
           </b-form-input>
      </b-form-group>            
        
      <b-form-group id="authorizedAdmins"
                    label="Authorized Admins:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                   
                    label-for="formauthorizedAdmins">
          <b-form-input id="authorizedAdmins"
                      label="authorizedAdmins"
                      label-for="exampleInput2"
                      v-model="basic.authorizedAdmins"
                      @input="$v.basic.authorizedAdmins.$touch()"
                      :state="!$v.basic.authorizedAdmins.$invalid"
                      placeholder="Enter Authorized Admins">
           </b-form-input>
      </b-form-group>

      <b-form-group id="formbillingID"
                    label="BillingID:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="formbillingID">
          <b-form-input id="billingID"
                      label="billingID"
                      label-for="exampleInput2"
                      v-model="basic.billingID"
                      @input="$v.basic.billingID.$touch()"
                      :state="!$v.basic.billingID.$invalid"
                      placeholder="Enter Billing ID">
           </b-form-input>
      </b-form-group>
  </b-col>
  </b-row>
  </b-tab>

  <b-tab title="Replica VM Details" class="mt-3" :disabled="$v.basic.$invalid" :title-item-class="linkActive(1)">
  <b-row>
  <b-col md="8" sm="12" xs="12">
      <b-form-group id="exampleInput1"
                    label="Master VM"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="masterVM"
                      label="Master VM"
                      label-for="masterVM"
                      v-model="form.masterVM"
                      @input="$v.form.masterVM.$touch()"
                      :state="!$v.form.masterVM.$invalid"
                      placeholder="Select Master VM">
        </b-form-input>
      </b-form-group>

      <b-form-group id="exampleInput1"
                    label="Source Directory"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="sourceDirectory"
                      label="Source Directory"
                      label-for="exampleInput2"
                      v-model="form.sourceDirectory"
                      @input="$v.form.sourceDirectory.$touch()"
                      :state="!$v.form.sourceDirectory.$invalid"
                      placeholder="Enter Source Directory">
        </b-form-input>
      </b-form-group>

      <b-form-group id="exampleInput1"
                    label="Replica VM:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="replicaVM"
                      label="Replica VM"
                      label-for="exampleInput2"
                      v-model="form.replicaVM"
                      @input="$v.form.replicaVM.$touch()"
                      :state="!$v.form.replicaVM.$invalid"
                      placeholder="Enter Replica VM">
        </b-form-input>
      </b-form-group>

      <b-form-group id="exampleInput1"
                    label="Destination Directory:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="destinationDirectory"
                      label="Destination Directory"
                      label-for="exampleInput2"
                      v-model="form.destinationDirectory"
                      @input="$v.form.destinationDirectory.$touch()"
                      :state="!$v.form.destinationDirectory.$invalid"
                      placeholder="Enter Destination Directory">
        </b-form-input>
      </b-form-group>

      <b-form-group id="exampleInput1"
                    label="Order Details:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="exampleInput1">
        <b-form-input id="orderDetails"
                      label="Order Details"
                      label-for="exampleInput2"
                      v-model="form.orderDetails"
                      @input="$v.form.orderDetails.$touch()"
                      :state="!$v.form.orderDetails.$invalid"
                      placeholder="Enter Order Details">
        </b-form-input>
      </b-form-group>
        </b-col>
        </b-row>
  </b-tab>
</b-tabs>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'PlaceOrder',
  data () {
    return {
      tabIndex: 0,
      auth: this.$store.state.auth,
      basic: {},
      form: {},
      resourceName: '',
      csiID: '',
      billingID: '',
      authorizedAdmins: '',
      masterVM: '',
      sourceDirectory: '',
      replicaVM: '',
      destinationDirectory: '',
      orderInfo: ''
    }
  },
  mixins: [validationMixin],
  validations: {
    basic: {
      resourceName: {
        required
      },
      csiID: {
        required
      },
      authorizedAdmins: {
        required
      },
      billingID: {
        required
      }
      },
      form: {
      masterVM: {
        required
      },
      sourceDirectory: {
        required
      },
      replicaVM: {
        required
      },
      destinationDirectory: {
        required
      },
      orderDetails: {
        required
      }
    }

  },
  methods: {
    linkActive (idx) {
      if (this.tabIndex === idx) {
        return ['active']
      } 
    }
  }
}
</script>
