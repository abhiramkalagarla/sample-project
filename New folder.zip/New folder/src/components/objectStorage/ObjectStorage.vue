<template>
<b-tabs>
  <b-tab title="first" active>
    <br>I'm the first fading tab

    <b-form-group id="exampleInput1"
                    label="Resource Name:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                   
                    label-for="exampleInput1">
        <b-form-input id="resourceName"
                      label="Resource Name"
                      label-for="exampleInput2"
                      v-model="form.resourceName"
                      @input="$v.form.resourceName.$touch()"
                      :state="!$v.form.resourceName.$invalid"
                      placeholder="Enter Resource Name">
        </b-form-input>
      </b-form-group>
      
  </b-tab>
  <b-tab title="second" >
    <br>I'm the second tab content
  </b-tab>
</b-tabs>
</template>
