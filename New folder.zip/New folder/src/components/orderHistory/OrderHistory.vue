<template>
  <b-row>
  <b-col class="mt-10">
   <h2>Order History</h2>
</b-col>

  </b-row>
</template>

<script>
export default {
  name: 'OrderHistory',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
