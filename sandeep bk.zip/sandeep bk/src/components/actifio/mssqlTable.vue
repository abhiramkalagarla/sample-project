<template>
  <div class="mt-2">
  <p><b>Fill the below MSSQL table with details*</b></p>
<b-row>
  <b-col md="4">
    <b-form-group id="Group1"
      description="The entered server will be treated as Primary Database server for Database protection service">
        <b-input-group>
              <b-form-input id="serverId"
                    type="text"
                    v-model="actifio.serverId"
                    aria-describedby="serverId"
                    placeholder="Enter Server Name" />
                    <b-input-group-append>
                    <button @click="getserverInfo()" class="btn btn-primary" >Add Server</button>
                    </b-input-group-append>
        </b-input-group> 
        <span class="invalid-feedback d-block" v-if="isServerAssociated">The Entered Server Name is not associated with the given CSIID. Please try again...</span>
        <span class="invalid-feedback d-block" v-if="isserverNameValid">The Entered Server Name is invalid. Please try again...</span>
    </b-form-group>
  </b-col>
  </b-row>
    <v-client-table :data="tableData" :columns="mssqlcolumns" :options="mssqloptions"></v-client-table>

    <b-modal v-model="showModal_mssql" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef_mssql" :title="popupTitle_mssql"  @hidden="onHidden_mssql">
      <form @submit.stop.prevent="handleSubmit">
           <b-form-group id="DataCenter"
                      label="Server Name"
                      class="required"
                      label-for="servernameInput">
          <b-form-input id="servernameInput"
                      type="text"
                      v-model="form_mssql.serverName"
                      :state="null"
                      aria-describedby="servernameInput"
                      placeholder="Enter Server Name"/>
          <b-form-invalid-feedback id="servernameInput">
            This is a required field
          </b-form-invalid-feedback>
          
          </b-form-group>

          <b-form-group id="OfflinePools"
                        label="Type*:"
                        description="Select the Database Type"
                        :label-cols="2"
                        breakpoint="md"
                        label-for="type_mssql">
            <b-form-select id="type_mssql"
                        :options="type_mssql"
                        v-model="form_mssql.type_mssql"
                        aria-describedby="type_mssql"
                        placeholder="Select Server Typer"/>
            </b-form-group>

          <b-form-group id="DataCenter"
                      label="OS Type"
                      class="required"
                      label-for="osversionInput">
                      <b-form-select id="osversionInput"
                      :options="osVersion"
                      v-model="form_mssql.osVersion"
                      :state="null"
                      aria-describedby="osversionInput"
                      placeholder="Enter OS Type" />
          <b-form-invalid-feedback id="osversionInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Enter Instance Name"
                      class="required"
                      label-for="instancenameInput">
          <b-form-input id="instancenameInput"
                      type="text"
                      v-model="form_mssql.instanceNames"
                      :state="null"
                      aria-describedby="instancenameInput"
                      placeholder="Enter Instance Name Separated by Comma" />
          <b-form-invalid-feedback id="instancenameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Enter DB Size in GB"
                      class="required"
                      label-for="databasesizeInput">
          <b-form-input id="databasesizeInput"
                      type="text"
                      v-model="form_mssql.dbSize"
                      :state="null"
                      aria-describedby="databasesizeInput"
                      placeholder="Enter Database Size in GB" />
          <b-form-invalid-feedback id="databasesizeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

         <b-form-group id="DataCenter"
                      label="Enter Change Rate in % per day"
                      class="required"
                      label-for="changerateInput">
          <b-form-select id="changerateInput"
                      :options="dbChangeRate"
                      v-model="form_mssql.dbChangeRate"
                      aria-describedby="changerateInput"
                      placeholder="Enter Change Rate in % per day" />
          <b-form-invalid-feedback id="changeRateInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

            <b-form-group id="DataCenter"
                      label="Enter DB log size per day in GB"
                      class="required"
                      label-for="dblogsizeInput">
          <b-form-input id="dblogsizeInput"
                      type="text"
                      v-model="form_mssql.dbLogSize"
                      :state="null"
                      aria-describedby="dblogsizeInput"
                      placeholder="Enter DB log size per day in GB" />
          <b-form-invalid-feedback id="dblogsizeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster name/Listener name"
                      class="required"
                      label-for="clusternameInput">
          <b-form-input id="clusternameInput"
                      type="text"
                      v-model="form_mssql.clusterName"
                      :state="null"
                      aria-describedby="clusternameInput"
                      placeholder="Enter Cluster name" />
          <b-form-invalid-feedback id="clusternameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster Member Servers"
                      class="required"
                      label-for="clustermemberserversInput">
          <b-form-input id="clustermemberserversInput"
                      type="text"
                      v-model="form_mssql.clusterMembers"
                      :state="null"
                      aria-describedby="clustermemberserversInput"
                      placeholder="Cluster Member Servers Separated by Comma" />
          <b-form-invalid-feedback id="clustermemberserversInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>
            
          <b-button type="submit" :disabled="$v.form_mssql.$invalid" variant="primary" >
              Submit
          </b-button>
          <b-button type="button" @click="hidemodal_mssql()" variant="default">
            Cancel
          </b-button>
      </form>
    </b-modal>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required, requiredUnless, requiredIf } from 'vuelidate/lib/validators'
export default {
  name: 'mssqlTable',
  data () {
    return {
         showModal_mssql: false,
         popupTitle_mssql: 'New Server',
         theme: 'bootstrap4',
         actifio: {},
         form_mssql: {},
         isServerAssociated: false,
         isserverNameValid: false,
         hidefooter: true,
         template: 'default',
         dbChangeRate: ['3%', '5%'],
         type_mssql: ['Choose...', 'Standalone', 'SQL Local instance in Availabilty group', 'Failover', 'SQL Availability group'],
         osVersion: ['Windows', 'Linux', 'AIX'],
         mssqlcolumns: ['serverName', 'type_mssql', 'osVersion', 'instanceNames', 'dbSize', 'dbChangeRate', 'dbLogSize', 'clusterMembers', 'clusterName'],
         tableData: [],
         mssqloptions: {
            templates: {
          },
          headings: {
                serverName: 'ServerName',
                type_mssql: 'Type',
                osVersion: 'OS Type',
                instanceNames: 'Instance name',
                dbSize: 'Database Size in GB',
                dbChangeRate: 'Change Rate in % per day',
                dbLogSize: 'DB log size per day in GB',
                clusterMembers: 'Cluster Member Servers',
                clusterName: 'Cluster name'
            },
          text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
          filterable: false,
          perPage: 10,
          pagination: { chunk: 10, dropdown: false }
            // see the options API
          }
    }
  },
  mixins: [validationMixin],
  validations () {
    const valdef = {
      form_mssql: {
      serverName: {
        required
      },
      type_mssql: {
        required
      },
      osVersion: {
        required
      },
      instanceNames: {
        required
      },
      dbSize: {
        required
      },
      dbChangeRate: {
        required
      },
      dbLogSize: {
        required
      }
    }
    }
    if (this.form_mssql.type_mssql === 'Failover' || this.form_mssql.type_mssql === 'SQL Availability group') {
    valdef.form_mssql.clusterName = {required};
    valdef.form_mssql.clusterMembers = {required};
    }
    return valdef
  },
  created () {
    this.$emit('update', true)
    // this.getAppInfo();
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    handleSubmit (e) {
      e.preventDefault()
      this.tableData.push(this.form_mssql)
      this.$emit('update', false)
      this.hidemodal_mssql()
    },
    onHidden_mssql () {
      this.osVersion = ['Windows', 'Linux', 'AIX']
      this.form_mssql = {}
      this.popupTitle_mssql = 'New Pool'
      this.showModal_mssql = false
    },
    hidemodal_mssql () {
      this.$refs.myModalRef_mssql.hide()
    },
    newserver_mssql () {
        this.showModal_mssql = true
        this.popupTitle_mssql = 'New Server' 
        this.$refs.myModalRef_mssql.show()
    },
    getserverInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'
  }
}     
      this.$http
        .get('https://mystorage.nam.nsroot.net:8080/api/servers?serverName=' + this.actifio.serverId, apiheaders)
        .then((response) => {
          this.serverInfo = response;
          this.form_mssql.serverName = response.body.serverName;
          this.osVersion.push(response.body.osVersion);
          this.form_mssql.osVersion = response.body.osVersion;
          for (var i = 0; i < response.body.CSIID.length; i++) {
            if (response.body.CSIID[i] === this.$parent.actifio.CSIID) {
            this.newserver_mssql();
            this.isServerAssociated = false;
            break;
            } else {
              this.isServerAssociated = true;
            }
          }
          this.isserverNameValid = false;
        })
        .catch((response) => {
          this.isserverNameValid = true;
          console.log(response)
        })
    }
  }
}
</script>
