<template>
  <div class="mt-2">
  <p><b>Fill the below Oracle table with details*</b></p>
<b-row>
  <b-col md="4">
      <b-form-group id="Group1"
          description="Enter multiple servers by selecting Add server based on the SQL configuration ">
            <b-input-group>
              <b-form-input id="appID"
                    type="text"
                    v-model="actifio.appiD"
                    aria-describedby="appID"
                    placeholder="Enter Server Name" />
                    <b-input-group-append>
                    <button @click="getserverInfo()" class="btn btn-primary" >Add Server</button>
                    </b-input-group-append>
            </b-input-group>
            <span class="invalid-feedback d-block" v-if="isServerAssociated">The Entered Server Name is not associated with the given CSIID. Please try again...</span>
        <span class="invalid-feedback d-block" v-if="isserverNameValid">The Entered Server Name is invalid. Please try again...</span>              
        </b-form-group>
  </b-col>
</b-row>
    <v-client-table :data="oracletableData" :columns="oraclecolumns" :options="oracleoptions"></v-client-table>

    <b-modal v-model="showModal_oracle" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef_oracle" :title="popupTitle_oracle"  @hidden="onHidden_oracle">
      <form @submit.stop.prevent="handleSubmit">
          <b-form-group id="DataCenter"
                      label="Server Name"
                      class="required"
                      label-for="servernameInput">
          <b-form-input id="servernameInput"
                      type="text"
                      v-model="form_oracle.serverName"
                      :state="null"
                      aria-describedby="servernameInput"
                      placeholder="Enter Server Name"/>
          <b-form-invalid-feedback id="servernameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="OfflinePools"
                        label="Type*:"
                        description="Select the Database Type"
                        :label-cols="2"
                        breakpoint="md"
                        label-for="type_oracle">
            <b-form-select id="type_oracle"
                        :options="type_oracle"
                        v-model="form_oracle.type_oracle"
                        aria-describedby="type_oracle"
                        placeholder="Select Server Typer"/>
            </b-form-group>

          <b-form-group id="DataCenter"
                      label="OS Version"
                      class="required"
                      label-for="osversionInput">
          <b-form-select id="osversionInput"
                      :options="osVersion"
                      v-model="form_oracle.osVersion"
                      :state="null"
                      aria-describedby="osversionInput"
                      placeholder="Enter OS Type" />
          <b-form-invalid-feedback id="osversionInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Enter Database Name"
                      class="required"
                      label-for="databasenameInput">
          <b-form-input id="databasenameInput"
                      type="text"
                      v-model="form_oracle.dbNames"
                      :state="null"
                      aria-describedby="databasenameInput"
                      placeholder="Enter Database Name Separated by Comma" />
          <b-form-invalid-feedback id="databasenameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Enter DB Size in GB"
                      class="required"
                      label-for="databasesizeInput">
          <b-form-input id="databasesizeInput"
                      type="text"
                      v-model="form_oracle.dbSize"
                      :state="null"
                      aria-describedby="databasesizeInput"
                      placeholder="Enter Database Size in GB" />
          <b-form-invalid-feedback id="databasesizeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Enter Change Rate in % per day"
                      class="required"
                      label-for="changerateInput">
          <b-form-select id="changerateInput"
                      :options="dbChangeRate"
                      v-model="form_oracle.dbChangeRate"
                      aria-describedby="changerateInput"
                      placeholder="Enter Change Rate in % per day" />
          <b-form-invalid-feedback id="changeRateInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

            <b-form-group id="DataCenter"
                      label="Enter DB log size per day in GB"
                      class="required"
                      label-for="dblogsizeInput">
          <b-form-input id="dblogsizeInput"
                      type="text"
                      v-model="form_oracle.dbLogSize"
                      :state="null"
                      aria-describedby="dblogsizeInput"
                      placeholder="Enter DB log size per day in GB" />
          <b-form-invalid-feedback id="dblogsizeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster Member Servers"
                      class="required"
                      label-for="clustermemberserversInput">
          <b-form-input id="clustermemberserversInput"
                      type="text"
                      v-model="form_oracle.clusterMembers"
                      :state="null"
                      aria-describedby="clustermemberserversInput"
                      placeholder="Cluster Member Servers" />
          <b-form-invalid-feedback id="clustermemberserversInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster name"
                      class="required"
                      label-for="clusternameInput">
          <b-form-input id="clusternameInput"
                      type="text"
                      v-model="form_oracle.clusterName"
                      :state="null"
                      aria-describedby="clusternameInput"
                      placeholder="Enter Cluster name" />
          <b-form-invalid-feedback id="clusternameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" :disabled="$v.form_oracle.$invalid" variant="primary" >
              Submit
          </b-button>
          <b-button type="button" @click="hidemodal_oracle()" variant="default">
            Cancel
          </b-button>
      </form>
    </b-modal>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required, requiredUnless, requiredIf } from 'vuelidate/lib/validators'
export default {
  name: 'oracle',
  data () {
    return {
         showModal_oracle: false,
         popupTitle_oracle: 'New Server',
         theme: 'bootstrap4',
         isServerAssociated: false,
         isserverNameValid: false,
         form_oracle: {},
         actifio: {},
         hidefooter: true,
         template: 'default',
         dbChangeRate: ['3%', '5%'],
         type_oracle: ['Choose...', 'Filesystem Standalone', 'ASM Standalone', 'Filesystem Cluster', 'ASM Clustered', 'RAC on ASM'],
         osVersion: ['Windows', 'Linux', 'AIX'],
         oraclecolumns: ['serverName', 'type_oracle', 'osVersion', 'dbNames', 'dbSize', 'dbChangeRate', 'dbLogSize', 'clusterMembers', 'clusterName'],
         oracletableData: [],
         oracleoptions: {
         templates: {
            },
          headings: {
                serverName: 'ServerName',
                type_oracle: 'Type',
                osVersion: 'OS Type',
                dbNames: 'Database name',
                dbSize: 'Database Size in GB',
                dbChangeRate: 'Change Rate in % per day',
                dbLogSize: 'DB log size per day in GB',
                clusterMembers: 'Cluster Member Servers',
                clusterName: 'Cluster name'
            },
          text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
          filterable: false,
          perPage: 10,
          pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations () {
    const valdef = {
    form_oracle: {
      serverName: {
        required
      },
      type_oracle: {
        required
      },
      osVersion: {
        required
      },
      dbNames: {
        required
      },
      dbSize: {
        required
      },
      dbChangeRate: {
        required
      },
      dbLogSize: {
        required
      }
      }
    }
    if (this.form_oracle.type_oracle === 'Filesystem Cluster' || this.form_oracle.type_oracle === 'ASM Clustered' || this.form_oracle.type_oracle === 'RAC on ASM') {
    valdef.form_oracle.clusterName = {required};
    valdef.form_oracle.clusterMembers = {required};
    }
    return valdef
  },
  created () {
    // this.getAppInfo();
  },
  methods: {
    handleSubmit (e) {
      e.preventDefault()
      this.oracletableData.push(this.form_oracle)
      this.$emit('update', false)
      this.hidemodal_oracle()
    },
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    onHidden_oracle () {
      this.osVersion = ['Windows', 'Linux', 'AIX']
      this.form_oracle = {}
      this.popupTitle_oracle = 'New Pool'
      this.showModal_oracle = false
    },
    hidemodal_oracle () {
    this.$refs.myModalRef_oracle.hide()
    },
    newserver_oracle () {
        this.showModal_oracle = true
        this.popupTitle_oracle = 'New Server' 
        this.$refs.myModalRef_oracle.show()
    },
    getserverInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'
  }
}     
      this.$http
        .get('https://mystorage.nam.nsroot.net:8080/api/servers?serverName=' + this.actifio.appiD, apiheaders)
        .then((response) => {
          console.log()
          this.serverInfo = response;
          this.form_oracle.serverName = response.body.serverName;
          this.osVersion.push(response.body.osVersion);
          this.form_oracle.osVersion = response.body.osVersion;
          for (var i = 0; i < response.body.CSIID.length; i++) {
            if (response.body.CSIID[i] === this.$parent.actifio.CSIID) {
            this.newserver_oracle();
            this.isServerAssociated = false;
            break;
            } else {
              this.isServerAssociated = true;
            }
          }
          this.isserverNameValid = false;
        })
        .catch((response) => {
          this.isserverNameValid = true;
          console.log(response)
        })
    }
  }
}
</script>
