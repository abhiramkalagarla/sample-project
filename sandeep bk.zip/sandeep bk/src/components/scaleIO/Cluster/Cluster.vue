<template>
  <div>
    <v-client-table :data="tableData" :columns="columns" :options="options">
    </v-client-table>
  </div>
</template>

<script>
export default {
  name: 'Cluster',
  data () {
    return {
      theme: 'bootstrap4',
        currentItem: {},
        template: 'default',
        columns: ['host', 'sioClusterName'],
        tableData: [],
        options: {
            templates: {
        },
            headings: {
                host: 'Host',
                sioClusterName: 'Cluster Name'
            },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  created () {
    this.getAllClusters();
  },
  methods: {
    getAllClusters () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
      const infoProps = {
        'workflowSync': 'getSIOClusters'
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
         this.tableData = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
