<template>
  <section class="login-block">
  <b-container>
  <b-row>
  <b-col sm="4">
  <h2 class="text-center">Login Now</h2>
        <b-form @submit="onSubmit">
        <b-form-group id="DomainInputGroup"
                  label="Domain"
                  class="required"
                  label-for="DomainGroup">
      <b-form-select id="DomainGroup"
                     :options="Domains"
                     @input="$v.form.Domain.$touch()"
                     :state="null"
                     v-model="form.Domain" />
      <b-form-invalid-feedback id="input2LiveFeedback" >
        This is a required field
      </b-form-invalid-feedback>
      
    </b-form-group>

    <b-form-group id="SOEID"
                  label="SOEID"
                  class="required"
                  label-for="soeidinput">
      <b-form-input id="soeidinput"
                    type="text"
                    @input="$v.form.SOEID.$touch()"
                    v-model="form.SOEID"
                    :state="null"
                    aria-describedby="SoeidFeedback"
                    placeholder="Enter SOEID" />
      <b-form-invalid-feedback id="SoeidFeedback">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
    <b-form-group id="Password"
                  label="Password"
                  class="required"
                  label-for="passwordInput">
      <b-form-input id="passwordInput"
                    type="password"
                    v-model="form.Password"
                    :state="null"
                    aria-describedby="passwordFeedback"
                    placeholder="Enter Password" />
      <b-form-invalid-feedback id="passwordFeedback">
        This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
    <b-button type="submit"
              variant="primary"
              :disabled="$v.form.$invalid">
      Submit
    </b-button>
  </b-form>
  </b-col>
  <b-col md="8">
  <b-carousel id="carousel1"
                style="text-shadow: 1px 1px 2px #333;"
                controls
                indicators
                background="#ababab"
                :interval="4000"
                img-width="1024"
                img-height="480"
    >

      <b-carousel-slide caption="Citi OMS"
                        img-src="https://static.pexels.com/photos/33972/pexels-photo.jpg"
      ></b-carousel-slide>
      <b-carousel-slide img-src="https://images.pexels.com/photos/7097/people-coffee-tea-meeting.jpg">
        <div class="banner-text">
                  <h2>This is Heaven</h2>
                 
                </div>
      </b-carousel-slide>

    </b-carousel>
  </b-col>
  </b-row>
  </b-container>
</section>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'

export default {
  name: 'myForm',
  data () {
    return {
      Domains: ['NAM', 'EUR', 'APAC'],
      form: {},
      loggingIn: false,
      error: ''
    }
  },
  mixins: [validationMixin],
  validations: {
    form: {
      Domain: {
        required
      },
      SOEID: {
        required
      },
      Password: {
        required
      }
    }
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.authenticate()
                },
    authenticate () {
      let domain = '';
      switch (this.form.Domain) {
        case 'NAM':
        domain = '@nam.nsroot.net';
        break;
        case 'EUR':
        domain = '@eur.nsroot.net';
        break;
        case 'APAC':
        domain = '@apac.nsroot.net';
        break;
      }
      this.loggingIn = true
      const credentials = {
        'domain': this.form.Domain,
        'soeID': this.form.SOEID + domain,
        'password': this.form.Password
      }
      this.$auth.login(credentials, 'dashboard').then((response) => {
        this.loggingIn = false
        // this.error = utils.getError(response)
      })
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
