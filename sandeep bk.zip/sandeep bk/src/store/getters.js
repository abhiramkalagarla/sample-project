export const user = state => state.user
